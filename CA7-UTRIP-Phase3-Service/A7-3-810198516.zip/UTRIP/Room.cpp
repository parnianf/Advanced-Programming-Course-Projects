#include"Room.hpp"
#include"StructsAndDefines.hpp"
using namespace std;


Room::Room(string roomId_,RoomType type_){
    roomId = roomId_;
    type = type_;
}
